# Vicky Gupta — Developer Portfolio

A single-page, dark-theme student developer portfolio built with HTML5, CSS3, and a small amount of JavaScript for the mobile navigation menu.

## Files
- `index.html` — page structure and content
- `style.css` — styling, layout, and responsive design
- `script.js` — mobile navigation menu interaction

## Run locally
1. Open this folder in VS Code.
2. Open `index.html` using Live Server, or open the file in a browser.
3. Update the GitHub and LinkedIn links in `index.html` to your real profiles before submission.

## Before submitting
- Confirm all required sections and their order against the full NIAT assignment instructions.
- Replace any practice-project descriptions with links to your actual work when available.
- Push all three source files to a **public** GitHub repository.
- Deploy using the hosting method/domain required by NIAT.
- Capture the complete deployed page and export it to `vicky_gupta_portfolio.pdf`.

Note: This starter is based on the assignment requirements visible in the supplied screenshots. Check the complete assignment page for any additional required section order or details before final submission.
